package com.shivay.myapplicationcalapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
class MainActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var edit_first = findViewById<EditText>(R.id.edit_first)
        var edit_second = findViewById<EditText>(R.id.edit_second)

        var display_result = findViewById<TextView>(R.id.display_result)



        var edtadd=findViewById<Button>(R.id.edtadd)
      edtadd.setOnClickListener {

            var Number1 : Int = edit_first.text.toString().toInt()
            var Number2 : Int = edit_second.text.toString().toInt()

            var additionAnswer = Number1 + Number2

            display_result.text = String.format("$Number1"+"+"+"$Number2"+"="+"$additionAnswer")

        }

        var edtSub = findViewById<Button>(R.id.edtSub)
        edtSub.setOnClickListener {

            var Number1 : Int = edit_first.text.toString().toInt()
            var Number2 : Int = edit_second.text.toString().toInt()

            var additionAnswer = Number1 + Number2

            display_result.text = String.format("$Number1"+"+"+"$Number2"+"="+"$additionAnswer")
        }

        var edtMultiply = findViewById<Button>(R.id.edtmultiply)
        edtMultiply.setOnClickListener {

            var Number1 : Int = edit_first.text.toString().toInt()
            var Number2 : Int = edit_second.text.toString().toInt()

            var additionAnswer = Number1 + Number2

            display_result.text = String.format("$Number1"+"+"+"$Number2"+"="+"$additionAnswer")
        }

        var edtDiv = findViewById<Button>(R.id.edtDiv)
        edtDiv.setOnClickListener {

            var Number1 : Int = edit_first.text.toString().toInt()
            var Number2 : Int = edit_second.text.toString().toInt()

            var additionAnswer = Number1 + Number2

            display_result.text = String.format("$Number1"+"+"+"$Number2"+"="+"$additionAnswer")

        }


    }
}

